import "./chunk-ZU5Q2RJ3.js";
import {
  f
} from "./chunk-OEB3O3NY.js";
import {
  RecordingStatus
} from "./chunk-MJ4UJ75N.js";
import {
  Capacitor,
  WebPlugin,
  registerPlugin
} from "./chunk-F3ALAPII.js";
import {
  __async,
  __commonJS,
  __toESM
} from "./chunk-Q3N56TRI.js";

// node_modules/get-blob-duration/node_modules/@babel/runtime/helpers/interopRequireDefault.js
var require_interopRequireDefault = __commonJS({
  "node_modules/get-blob-duration/node_modules/@babel/runtime/helpers/interopRequireDefault.js"(exports, module) {
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : {
        "default": obj
      };
    }
    module.exports = _interopRequireDefault;
  }
});

// node_modules/regenerator-runtime/runtime.js
var require_runtime = __commonJS({
  "node_modules/regenerator-runtime/runtime.js"(exports, module) {
    var runtime = (function(exports2) {
      "use strict";
      var Op = Object.prototype;
      var hasOwn = Op.hasOwnProperty;
      var defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
      };
      var undefined2;
      var $Symbol = typeof Symbol === "function" ? Symbol : {};
      var iteratorSymbol = $Symbol.iterator || "@@iterator";
      var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
      var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
      function define(obj, key, value) {
        Object.defineProperty(obj, key, {
          value,
          enumerable: true,
          configurable: true,
          writable: true
        });
        return obj[key];
      }
      try {
        define({}, "");
      } catch (err) {
        define = function(obj, key, value) {
          return obj[key] = value;
        };
      }
      function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
        var generator = Object.create(protoGenerator.prototype);
        var context = new Context(tryLocsList || []);
        defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) });
        return generator;
      }
      exports2.wrap = wrap;
      function tryCatch(fn, obj, arg) {
        try {
          return { type: "normal", arg: fn.call(obj, arg) };
        } catch (err) {
          return { type: "throw", arg: err };
        }
      }
      var GenStateSuspendedStart = "suspendedStart";
      var GenStateSuspendedYield = "suspendedYield";
      var GenStateExecuting = "executing";
      var GenStateCompleted = "completed";
      var ContinueSentinel = {};
      function Generator() {
      }
      function GeneratorFunction() {
      }
      function GeneratorFunctionPrototype() {
      }
      var IteratorPrototype = {};
      define(IteratorPrototype, iteratorSymbol, function() {
        return this;
      });
      var getProto = Object.getPrototypeOf;
      var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
      if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
        IteratorPrototype = NativeIteratorPrototype;
      }
      var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
      GeneratorFunction.prototype = GeneratorFunctionPrototype;
      defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: true });
      defineProperty(
        GeneratorFunctionPrototype,
        "constructor",
        { value: GeneratorFunction, configurable: true }
      );
      GeneratorFunction.displayName = define(
        GeneratorFunctionPrototype,
        toStringTagSymbol,
        "GeneratorFunction"
      );
      function defineIteratorMethods(prototype) {
        ["next", "throw", "return"].forEach(function(method) {
          define(prototype, method, function(arg) {
            return this._invoke(method, arg);
          });
        });
      }
      exports2.isGeneratorFunction = function(genFun) {
        var ctor = typeof genFun === "function" && genFun.constructor;
        return ctor ? ctor === GeneratorFunction || // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction" : false;
      };
      exports2.mark = function(genFun) {
        if (Object.setPrototypeOf) {
          Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
        } else {
          genFun.__proto__ = GeneratorFunctionPrototype;
          define(genFun, toStringTagSymbol, "GeneratorFunction");
        }
        genFun.prototype = Object.create(Gp);
        return genFun;
      };
      exports2.awrap = function(arg) {
        return { __await: arg };
      };
      function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
          var record = tryCatch(generator[method], generator, arg);
          if (record.type === "throw") {
            reject(record.arg);
          } else {
            var result = record.arg;
            var value = result.value;
            if (value && typeof value === "object" && hasOwn.call(value, "__await")) {
              return PromiseImpl.resolve(value.__await).then(function(value2) {
                invoke("next", value2, resolve, reject);
              }, function(err) {
                invoke("throw", err, resolve, reject);
              });
            }
            return PromiseImpl.resolve(value).then(function(unwrapped) {
              result.value = unwrapped;
              resolve(result);
            }, function(error) {
              return invoke("throw", error, resolve, reject);
            });
          }
        }
        var previousPromise;
        function enqueue(method, arg) {
          function callInvokeWithMethodAndArg() {
            return new PromiseImpl(function(resolve, reject) {
              invoke(method, arg, resolve, reject);
            });
          }
          return previousPromise = // If enqueue has been called before, then we want to wait until
          // all previous Promises have been resolved before calling invoke,
          // so that results are always delivered in the correct order. If
          // enqueue has not been called before, then it is important to
          // call invoke immediately, without waiting on a callback to fire,
          // so that the async generator function has the opportunity to do
          // any necessary setup in a predictable way. This predictability
          // is why the Promise constructor synchronously invokes its
          // executor callback, and why async functions synchronously
          // execute code before the first await. Since we implement simple
          // async functions in terms of async generators, it is especially
          // important to get this right, even though it requires care.
          previousPromise ? previousPromise.then(
            callInvokeWithMethodAndArg,
            // Avoid propagating failures to Promises returned by later
            // invocations of the iterator.
            callInvokeWithMethodAndArg
          ) : callInvokeWithMethodAndArg();
        }
        defineProperty(this, "_invoke", { value: enqueue });
      }
      defineIteratorMethods(AsyncIterator.prototype);
      define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
      });
      exports2.AsyncIterator = AsyncIterator;
      exports2.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        if (PromiseImpl === void 0) PromiseImpl = Promise;
        var iter = new AsyncIterator(
          wrap(innerFn, outerFn, self, tryLocsList),
          PromiseImpl
        );
        return exports2.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
      };
      function makeInvokeMethod(innerFn, self, context) {
        var state = GenStateSuspendedStart;
        return function invoke(method, arg) {
          if (state === GenStateExecuting) {
            throw new Error("Generator is already running");
          }
          if (state === GenStateCompleted) {
            if (method === "throw") {
              throw arg;
            }
            return doneResult();
          }
          context.method = method;
          context.arg = arg;
          while (true) {
            var delegate = context.delegate;
            if (delegate) {
              var delegateResult = maybeInvokeDelegate(delegate, context);
              if (delegateResult) {
                if (delegateResult === ContinueSentinel) continue;
                return delegateResult;
              }
            }
            if (context.method === "next") {
              context.sent = context._sent = context.arg;
            } else if (context.method === "throw") {
              if (state === GenStateSuspendedStart) {
                state = GenStateCompleted;
                throw context.arg;
              }
              context.dispatchException(context.arg);
            } else if (context.method === "return") {
              context.abrupt("return", context.arg);
            }
            state = GenStateExecuting;
            var record = tryCatch(innerFn, self, context);
            if (record.type === "normal") {
              state = context.done ? GenStateCompleted : GenStateSuspendedYield;
              if (record.arg === ContinueSentinel) {
                continue;
              }
              return {
                value: record.arg,
                done: context.done
              };
            } else if (record.type === "throw") {
              state = GenStateCompleted;
              context.method = "throw";
              context.arg = record.arg;
            }
          }
        };
      }
      function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method;
        var method = delegate.iterator[methodName];
        if (method === undefined2) {
          context.delegate = null;
          if (methodName === "throw" && delegate.iterator["return"]) {
            context.method = "return";
            context.arg = undefined2;
            maybeInvokeDelegate(delegate, context);
            if (context.method === "throw") {
              return ContinueSentinel;
            }
          }
          if (methodName !== "return") {
            context.method = "throw";
            context.arg = new TypeError(
              "The iterator does not provide a '" + methodName + "' method"
            );
          }
          return ContinueSentinel;
        }
        var record = tryCatch(method, delegate.iterator, context.arg);
        if (record.type === "throw") {
          context.method = "throw";
          context.arg = record.arg;
          context.delegate = null;
          return ContinueSentinel;
        }
        var info = record.arg;
        if (!info) {
          context.method = "throw";
          context.arg = new TypeError("iterator result is not an object");
          context.delegate = null;
          return ContinueSentinel;
        }
        if (info.done) {
          context[delegate.resultName] = info.value;
          context.next = delegate.nextLoc;
          if (context.method !== "return") {
            context.method = "next";
            context.arg = undefined2;
          }
        } else {
          return info;
        }
        context.delegate = null;
        return ContinueSentinel;
      }
      defineIteratorMethods(Gp);
      define(Gp, toStringTagSymbol, "Generator");
      define(Gp, iteratorSymbol, function() {
        return this;
      });
      define(Gp, "toString", function() {
        return "[object Generator]";
      });
      function pushTryEntry(locs) {
        var entry = { tryLoc: locs[0] };
        if (1 in locs) {
          entry.catchLoc = locs[1];
        }
        if (2 in locs) {
          entry.finallyLoc = locs[2];
          entry.afterLoc = locs[3];
        }
        this.tryEntries.push(entry);
      }
      function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal";
        delete record.arg;
        entry.completion = record;
      }
      function Context(tryLocsList) {
        this.tryEntries = [{ tryLoc: "root" }];
        tryLocsList.forEach(pushTryEntry, this);
        this.reset(true);
      }
      exports2.keys = function(val) {
        var object = Object(val);
        var keys = [];
        for (var key in object) {
          keys.push(key);
        }
        keys.reverse();
        return function next() {
          while (keys.length) {
            var key2 = keys.pop();
            if (key2 in object) {
              next.value = key2;
              next.done = false;
              return next;
            }
          }
          next.done = true;
          return next;
        };
      };
      function values(iterable) {
        if (iterable) {
          var iteratorMethod = iterable[iteratorSymbol];
          if (iteratorMethod) {
            return iteratorMethod.call(iterable);
          }
          if (typeof iterable.next === "function") {
            return iterable;
          }
          if (!isNaN(iterable.length)) {
            var i = -1, next = function next2() {
              while (++i < iterable.length) {
                if (hasOwn.call(iterable, i)) {
                  next2.value = iterable[i];
                  next2.done = false;
                  return next2;
                }
              }
              next2.value = undefined2;
              next2.done = true;
              return next2;
            };
            return next.next = next;
          }
        }
        return { next: doneResult };
      }
      exports2.values = values;
      function doneResult() {
        return { value: undefined2, done: true };
      }
      Context.prototype = {
        constructor: Context,
        reset: function(skipTempReset) {
          this.prev = 0;
          this.next = 0;
          this.sent = this._sent = undefined2;
          this.done = false;
          this.delegate = null;
          this.method = "next";
          this.arg = undefined2;
          this.tryEntries.forEach(resetTryEntry);
          if (!skipTempReset) {
            for (var name in this) {
              if (name.charAt(0) === "t" && hasOwn.call(this, name) && !isNaN(+name.slice(1))) {
                this[name] = undefined2;
              }
            }
          }
        },
        stop: function() {
          this.done = true;
          var rootEntry = this.tryEntries[0];
          var rootRecord = rootEntry.completion;
          if (rootRecord.type === "throw") {
            throw rootRecord.arg;
          }
          return this.rval;
        },
        dispatchException: function(exception) {
          if (this.done) {
            throw exception;
          }
          var context = this;
          function handle(loc, caught) {
            record.type = "throw";
            record.arg = exception;
            context.next = loc;
            if (caught) {
              context.method = "next";
              context.arg = undefined2;
            }
            return !!caught;
          }
          for (var i = this.tryEntries.length - 1; i >= 0; --i) {
            var entry = this.tryEntries[i];
            var record = entry.completion;
            if (entry.tryLoc === "root") {
              return handle("end");
            }
            if (entry.tryLoc <= this.prev) {
              var hasCatch = hasOwn.call(entry, "catchLoc");
              var hasFinally = hasOwn.call(entry, "finallyLoc");
              if (hasCatch && hasFinally) {
                if (this.prev < entry.catchLoc) {
                  return handle(entry.catchLoc, true);
                } else if (this.prev < entry.finallyLoc) {
                  return handle(entry.finallyLoc);
                }
              } else if (hasCatch) {
                if (this.prev < entry.catchLoc) {
                  return handle(entry.catchLoc, true);
                }
              } else if (hasFinally) {
                if (this.prev < entry.finallyLoc) {
                  return handle(entry.finallyLoc);
                }
              } else {
                throw new Error("try statement without catch or finally");
              }
            }
          }
        },
        abrupt: function(type, arg) {
          for (var i = this.tryEntries.length - 1; i >= 0; --i) {
            var entry = this.tryEntries[i];
            if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
              var finallyEntry = entry;
              break;
            }
          }
          if (finallyEntry && (type === "break" || type === "continue") && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc) {
            finallyEntry = null;
          }
          var record = finallyEntry ? finallyEntry.completion : {};
          record.type = type;
          record.arg = arg;
          if (finallyEntry) {
            this.method = "next";
            this.next = finallyEntry.finallyLoc;
            return ContinueSentinel;
          }
          return this.complete(record);
        },
        complete: function(record, afterLoc) {
          if (record.type === "throw") {
            throw record.arg;
          }
          if (record.type === "break" || record.type === "continue") {
            this.next = record.arg;
          } else if (record.type === "return") {
            this.rval = this.arg = record.arg;
            this.method = "return";
            this.next = "end";
          } else if (record.type === "normal" && afterLoc) {
            this.next = afterLoc;
          }
          return ContinueSentinel;
        },
        finish: function(finallyLoc) {
          for (var i = this.tryEntries.length - 1; i >= 0; --i) {
            var entry = this.tryEntries[i];
            if (entry.finallyLoc === finallyLoc) {
              this.complete(entry.completion, entry.afterLoc);
              resetTryEntry(entry);
              return ContinueSentinel;
            }
          }
        },
        "catch": function(tryLoc) {
          for (var i = this.tryEntries.length - 1; i >= 0; --i) {
            var entry = this.tryEntries[i];
            if (entry.tryLoc === tryLoc) {
              var record = entry.completion;
              if (record.type === "throw") {
                var thrown = record.arg;
                resetTryEntry(entry);
              }
              return thrown;
            }
          }
          throw new Error("illegal catch attempt");
        },
        delegateYield: function(iterable, resultName, nextLoc) {
          this.delegate = {
            iterator: values(iterable),
            resultName,
            nextLoc
          };
          if (this.method === "next") {
            this.arg = undefined2;
          }
          return ContinueSentinel;
        }
      };
      return exports2;
    })(
      // If this script is executing as a CommonJS module, use module.exports
      // as the regeneratorRuntime namespace. Otherwise create a new empty
      // object. Either way, the resulting object will be used to initialize
      // the regeneratorRuntime variable at the top of this file.
      typeof module === "object" ? module.exports : {}
    );
    try {
      regeneratorRuntime = runtime;
    } catch (accidentalStrictMode) {
      if (typeof globalThis === "object") {
        globalThis.regeneratorRuntime = runtime;
      } else {
        Function("r", "regeneratorRuntime = r")(runtime);
      }
    }
  }
});

// node_modules/get-blob-duration/node_modules/@babel/runtime/regenerator/index.js
var require_regenerator = __commonJS({
  "node_modules/get-blob-duration/node_modules/@babel/runtime/regenerator/index.js"(exports, module) {
    module.exports = require_runtime();
  }
});

// node_modules/get-blob-duration/node_modules/@babel/runtime/helpers/asyncToGenerator.js
var require_asyncToGenerator = __commonJS({
  "node_modules/get-blob-duration/node_modules/@babel/runtime/helpers/asyncToGenerator.js"(exports, module) {
    function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
      try {
        var info = gen[key](arg);
        var value = info.value;
      } catch (error) {
        reject(error);
        return;
      }
      if (info.done) {
        resolve(value);
      } else {
        Promise.resolve(value).then(_next, _throw);
      }
    }
    function _asyncToGenerator(fn) {
      return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
          var gen = fn.apply(self, args);
          function _next(value) {
            asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
          }
          function _throw(err) {
            asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
          }
          _next(void 0);
        });
      };
    }
    module.exports = _asyncToGenerator;
  }
});

// node_modules/get-blob-duration/dist/getBlobDuration.js
var require_getBlobDuration = __commonJS({
  "node_modules/get-blob-duration/dist/getBlobDuration.js"(exports) {
    "use strict";
    var _interopRequireDefault = require_interopRequireDefault();
    Object.defineProperty(exports, "__esModule", { value: true }), exports.default = getBlobDuration2;
    var _regenerator = _interopRequireDefault(require_regenerator());
    var _asyncToGenerator2 = _interopRequireDefault(require_asyncToGenerator());
    function getBlobDuration2(e) {
      return _getBlobDuration.apply(this, arguments);
    }
    function _getBlobDuration() {
      return (_getBlobDuration = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function e(r) {
        var t, n;
        return _regenerator.default.wrap(function(e2) {
          for (; ; ) switch (e2.prev = e2.next) {
            case 0:
              return t = document.createElement("video"), n = new Promise(function(e3, r2) {
                t.addEventListener("loadedmetadata", function() {
                  t.duration === 1 / 0 ? (t.currentTime = Number.MAX_SAFE_INTEGER, t.ontimeupdate = function() {
                    t.ontimeupdate = null, e3(t.duration), t.currentTime = 0;
                  }) : e3(t.duration);
                }), t.onerror = function(e4) {
                  return r2(e4.target.error);
                };
              }), t.src = "string" == typeof r || r instanceof String ? r : window.URL.createObjectURL(r), e2.abrupt("return", n);
            case 4:
            case "end":
              return e2.stop();
          }
        }, e);
      }))).apply(this, arguments);
    }
  }
});

// node_modules/@capacitor/filesystem/dist/esm/index.js
var Filesystem = registerPlugin("Filesystem", {
  web: () => import("./web-GC57TPHC.js").then((m) => new m.FilesystemWeb())
});
f();

// node_modules/capacitor-blob-writer/blob_writer.js
var BlobWriter = registerPlugin("BlobWriter");
function array_buffer_to_base64(buffer) {
  return window.btoa(
    Array.from(new Uint8Array(buffer)).map(function(byte) {
      return String.fromCharCode(byte);
    }).join("")
  );
}
function write_file_via_indexeddb({
  path,
  directory,
  blob,
  recursive
}) {
  return Filesystem.writeFile({
    directory,
    path,
    recursive,
    data: ""
  }).then(function() {
    return new Promise(function(resolve, reject) {
      function fail(event) {
        reject(event.target.error);
      }
      const connection = window.indexedDB.open("Disc");
      connection.onerror = fail;
      connection.onsuccess = function() {
        const db = connection.result;
        const transaction = db.transaction("FileStorage", "readwrite");
        transaction.onerror = fail;
        const store = transaction.objectStore("FileStorage");
        const name = `/${directory}/${path.replace(/^\//, "")}`;
        const load = store.get(name);
        load.onsuccess = function() {
          load.result.size = blob.size;
          load.result.content = blob;
          const put = store.put(load.result);
          put.onsuccess = function() {
            resolve(void 0);
          };
        };
      };
    });
  });
}
function write_file_via_bridge({
  path,
  directory,
  blob,
  recursive
}) {
  return Filesystem.writeFile({
    directory,
    path,
    recursive,
    data: ""
  }).then(function consume_blob() {
    if (blob.size === 0) {
      return Promise.resolve();
    }
    const chunk_size = 3 * 128 * 1024;
    const chunk_blob = blob.slice(0, chunk_size);
    blob = blob.slice(chunk_size);
    return new Response(
      chunk_blob
    ).arrayBuffer().then(function append_chunk_to_file(buffer) {
      return Filesystem.appendFile({
        directory,
        path,
        data: array_buffer_to_base64(buffer)
      });
    }).then(
      consume_blob
    );
  });
}
function write_blob(options) {
  const {
    path,
    directory,
    blob,
    fast_mode = false,
    recursive,
    on_fallback
  } = options;
  if (!blob || !Number.isSafeInteger(blob.size) || typeof blob.type !== "string") {
    return Promise.reject(new Error("Not a Blob."));
  }
  if (Capacitor.getPlatform() === "web") {
    return fast_mode ? write_file_via_indexeddb(options) : write_file_via_bridge(options);
  }
  return Promise.all([
    BlobWriter.get_config(),
    Filesystem.getUri({ path, directory })
  ]).then(function([config, file_info]) {
    const absolute_path = file_info.uri.replace("file://", "");
    const real_fetch = window.CapacitorWebFetch || window.fetch;
    return real_fetch(
      config.base_url + absolute_path + (recursive ? "?recursive=true" : ""),
      {
        headers: { authorization: config.auth_token },
        method: "put",
        body: blob
      }
    ).then(function(response) {
      if (response.status !== 204) {
        throw new Error("Bad HTTP status: " + response.status);
      }
      return file_info.uri;
    });
  }).catch(function on_fail(error) {
    if (on_fallback !== void 0) {
      on_fallback(error);
    }
    return write_file_via_bridge(options);
  });
}
var blob_writer_default = Object.freeze(write_blob);

// node_modules/capacitor-voice-recorder/dist/esm/VoiceRecorderImpl.js
var import_get_blob_duration = __toESM(require_getBlobDuration());

// node_modules/capacitor-voice-recorder/dist/esm/predefined-web-responses.js
var successResponse = () => ({ value: true });
var failureResponse = () => ({ value: false });
var missingPermissionError = () => new Error("MISSING_PERMISSION");
var alreadyRecordingError = () => new Error("ALREADY_RECORDING");
var deviceCannotVoiceRecordError = () => new Error("DEVICE_CANNOT_VOICE_RECORD");
var failedToRecordError = () => new Error("FAILED_TO_RECORD");
var emptyRecordingError = () => new Error("EMPTY_RECORDING");
var recordingHasNotStartedError = () => new Error("RECORDING_HAS_NOT_STARTED");
var failedToFetchRecordingError = () => new Error("FAILED_TO_FETCH_RECORDING");
var couldNotQueryPermissionStatusError = () => new Error("COULD_NOT_QUERY_PERMISSION_STATUS");

// node_modules/capacitor-voice-recorder/dist/esm/VoiceRecorderImpl.js
var POSSIBLE_MIME_TYPES = {
  "audio/aac": ".aac",
  "audio/mp4": ".mp3",
  "audio/webm;codecs=opus": ".ogg",
  "audio/webm": ".ogg",
  "audio/ogg;codecs=opus": ".ogg"
};
var neverResolvingPromise = () => new Promise(() => void 0);
var VoiceRecorderImpl = class _VoiceRecorderImpl {
  constructor() {
    this.mediaRecorder = null;
    this.chunks = [];
    this.pendingResult = neverResolvingPromise();
  }
  static canDeviceVoiceRecord() {
    return __async(this, null, function* () {
      var _a;
      if (((_a = navigator === null || navigator === void 0 ? void 0 : navigator.mediaDevices) === null || _a === void 0 ? void 0 : _a.getUserMedia) == null || _VoiceRecorderImpl.getSupportedMimeType() == null) {
        return failureResponse();
      } else {
        return successResponse();
      }
    });
  }
  startRecording(options) {
    return __async(this, null, function* () {
      if (this.mediaRecorder != null) {
        throw alreadyRecordingError();
      }
      const deviceCanRecord = yield _VoiceRecorderImpl.canDeviceVoiceRecord();
      if (!deviceCanRecord.value) {
        throw deviceCannotVoiceRecordError();
      }
      const havingPermission = yield _VoiceRecorderImpl.hasAudioRecordingPermission().catch(() => successResponse());
      if (!havingPermission.value) {
        throw missingPermissionError();
      }
      return navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => this.onSuccessfullyStartedRecording(stream, options)).catch(this.onFailedToStartRecording.bind(this));
    });
  }
  stopRecording() {
    return __async(this, null, function* () {
      if (this.mediaRecorder == null) {
        throw recordingHasNotStartedError();
      }
      try {
        this.mediaRecorder.stop();
        this.mediaRecorder.stream.getTracks().forEach((track) => track.stop());
        return this.pendingResult;
      } catch (ignore) {
        throw failedToFetchRecordingError();
      } finally {
        this.prepareInstanceForNextOperation();
      }
    });
  }
  static hasAudioRecordingPermission() {
    return __async(this, null, function* () {
      if (navigator.permissions.query == null) {
        if (navigator.mediaDevices == null) {
          return Promise.reject(couldNotQueryPermissionStatusError());
        }
        return navigator.mediaDevices.getUserMedia({ audio: true }).then(() => successResponse()).catch(() => {
          throw couldNotQueryPermissionStatusError();
        });
      }
      return navigator.permissions.query({ name: "microphone" }).then((result) => ({ value: result.state === "granted" })).catch(() => {
        throw couldNotQueryPermissionStatusError();
      });
    });
  }
  static requestAudioRecordingPermission() {
    return __async(this, null, function* () {
      const havingPermission = yield _VoiceRecorderImpl.hasAudioRecordingPermission().catch(() => failureResponse());
      if (havingPermission.value) {
        return successResponse();
      }
      return navigator.mediaDevices.getUserMedia({ audio: true }).then(() => successResponse()).catch(() => failureResponse());
    });
  }
  pauseRecording() {
    if (this.mediaRecorder == null) {
      throw recordingHasNotStartedError();
    } else if (this.mediaRecorder.state === "recording") {
      this.mediaRecorder.pause();
      return Promise.resolve(successResponse());
    } else {
      return Promise.resolve(failureResponse());
    }
  }
  resumeRecording() {
    if (this.mediaRecorder == null) {
      throw recordingHasNotStartedError();
    } else if (this.mediaRecorder.state === "paused") {
      this.mediaRecorder.resume();
      return Promise.resolve(successResponse());
    } else {
      return Promise.resolve(failureResponse());
    }
  }
  getCurrentStatus() {
    if (this.mediaRecorder == null) {
      return Promise.resolve({ status: RecordingStatus.NONE });
    } else if (this.mediaRecorder.state === "recording") {
      return Promise.resolve({ status: RecordingStatus.RECORDING });
    } else if (this.mediaRecorder.state === "paused") {
      return Promise.resolve({ status: RecordingStatus.PAUSED });
    } else {
      return Promise.resolve({ status: RecordingStatus.NONE });
    }
  }
  static getSupportedMimeType() {
    if ((MediaRecorder === null || MediaRecorder === void 0 ? void 0 : MediaRecorder.isTypeSupported) == null)
      return null;
    const foundSupportedType = Object.keys(POSSIBLE_MIME_TYPES).find((type) => MediaRecorder.isTypeSupported(type));
    return foundSupportedType !== null && foundSupportedType !== void 0 ? foundSupportedType : null;
  }
  onSuccessfullyStartedRecording(stream, options) {
    this.pendingResult = new Promise((resolve, reject) => {
      this.mediaRecorder = new MediaRecorder(stream);
      this.mediaRecorder.onerror = () => {
        this.prepareInstanceForNextOperation();
        reject(failedToRecordError());
      };
      this.mediaRecorder.onstop = () => __async(this, null, function* () {
        var _a, _b, _c;
        const mimeType = _VoiceRecorderImpl.getSupportedMimeType();
        if (mimeType == null) {
          this.prepareInstanceForNextOperation();
          reject(failedToFetchRecordingError());
          return;
        }
        const blobVoiceRecording = new Blob(this.chunks, { type: mimeType });
        if (blobVoiceRecording.size <= 0) {
          this.prepareInstanceForNextOperation();
          reject(emptyRecordingError());
          return;
        }
        let path;
        let recordDataBase64;
        if (options != null) {
          const subDirectory = (_c = (_b = (_a = options.subDirectory) === null || _a === void 0 ? void 0 : _a.match(/^\/?(.+[^/])\/?$/)) === null || _b === void 0 ? void 0 : _b[1]) !== null && _c !== void 0 ? _c : "";
          path = `${subDirectory}/recording-${(/* @__PURE__ */ new Date()).getTime()}${POSSIBLE_MIME_TYPES[mimeType]}`;
          yield blob_writer_default({
            blob: blobVoiceRecording,
            directory: options.directory,
            fast_mode: true,
            path,
            recursive: true
          });
        } else {
          recordDataBase64 = yield _VoiceRecorderImpl.blobToBase64(blobVoiceRecording);
        }
        const recordingDuration = yield (0, import_get_blob_duration.default)(blobVoiceRecording);
        this.prepareInstanceForNextOperation();
        resolve({ value: { recordDataBase64, mimeType, msDuration: recordingDuration * 1e3, path } });
      });
      this.mediaRecorder.ondataavailable = (event) => this.chunks.push(event.data);
      this.mediaRecorder.start();
    });
    return successResponse();
  }
  onFailedToStartRecording() {
    this.prepareInstanceForNextOperation();
    throw failedToRecordError();
  }
  static blobToBase64(blob) {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const recordingResult = String(reader.result);
        const splitResult = recordingResult.split("base64,");
        const toResolve = splitResult.length > 1 ? splitResult[1] : recordingResult;
        resolve(toResolve.trim());
      };
      reader.readAsDataURL(blob);
    });
  }
  prepareInstanceForNextOperation() {
    if (this.mediaRecorder != null && this.mediaRecorder.state === "recording") {
      try {
        this.mediaRecorder.stop();
      } catch (error) {
        console.warn("While trying to stop a media recorder, an error was thrown", error);
      }
    }
    this.pendingResult = neverResolvingPromise();
    this.mediaRecorder = null;
    this.chunks = [];
  }
};

// node_modules/capacitor-voice-recorder/dist/esm/web.js
var VoiceRecorderWeb = class extends WebPlugin {
  constructor() {
    super(...arguments);
    this.voiceRecorderInstance = new VoiceRecorderImpl();
  }
  canDeviceVoiceRecord() {
    return VoiceRecorderImpl.canDeviceVoiceRecord();
  }
  hasAudioRecordingPermission() {
    return VoiceRecorderImpl.hasAudioRecordingPermission();
  }
  requestAudioRecordingPermission() {
    return VoiceRecorderImpl.requestAudioRecordingPermission();
  }
  startRecording(options) {
    return this.voiceRecorderInstance.startRecording(options);
  }
  stopRecording() {
    return this.voiceRecorderInstance.stopRecording();
  }
  pauseRecording() {
    return this.voiceRecorderInstance.pauseRecording();
  }
  resumeRecording() {
    return this.voiceRecorderInstance.resumeRecording();
  }
  getCurrentStatus() {
    return this.voiceRecorderInstance.getCurrentStatus();
  }
};
export {
  VoiceRecorderWeb
};
//# sourceMappingURL=web-W3RQJAJQ.js.map
